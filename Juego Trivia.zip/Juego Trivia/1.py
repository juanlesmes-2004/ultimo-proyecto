import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk, ImageEnhance
import os


class ModernTriviaUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Triviados")
        self.root.configure(bg='#111827')  # Color de fondo oscuro moderno

        # Configurar estilos modernos
        self.setup_styles()

        # Contenedor principal con padding
        self.main_container = ttk.Frame(root, style='Modern.TFrame')
        self.main_container.pack(padx=30, pady=30, fill='both', expand=True)

        # Header Section
        self.create_header()

        # Cities Grid
        self.create_cities_grid()

        # Action Button
        self.create_action_button()

        # Footer
        self.create_footer()

    def setup_styles(self):
        style = ttk.Style()

        # Configuración de colores
        style.configure('Modern.TFrame', background='#111827')
        style.configure('Modern.TLabel',
                        background='#111827',
                        foreground='#F3F4F6')

        # Estilo para el botón principal
        style.configure('Action.TButton',
                        padding=(40, 15),
                        font=('Helvetica', 12, 'bold'))

        # Estilo para las tarjetas de ciudad
        style.configure('Card.TFrame',
                        background='#1F2937',
                        relief='flat')

        # Estilo para el footer
        style.configure('Footer.TLabel',
                        background='#111827',
                        foreground='#6B7280',
                        font=('Helvetica', 9))

    def create_header(self):
        # Logo o título principal
        title = ttk.Label(
            self.main_container,
            text="TRIVIADOS",
            font=('Helvetica', 24, 'bold'),
            style='Modern.TLabel'
        )
        title.pack(pady=(0, 10))

        # Subtítulo
        subtitle = ttk.Label(
            self.main_container,
            text="Compite en tiempo real con personas de todo el mundo",
            font=('Helvetica', 11),
            style='Modern.TLabel'
        )
        subtitle.pack(pady=(0, 30))

    def create_cities_grid(self):
        cities_frame = ttk.Frame(self.main_container, style='Modern.TFrame')
        cities_frame.pack(fill='x', pady=20)

        # Configurar el grid para que sea responsivo
        cities_frame.grid_columnconfigure(0, weight=1)
        cities_frame.grid_columnconfigure(1, weight=1)

        # Crear tarjetas de ciudad
        self.create_city_card(cities_frame, 0, "Nueva York", "1,000 jugadores", "nueva_york.jpg")
        self.create_city_card(cities_frame, 1, "Londres", "En vivo", "londres.jpg")

    def create_city_card(self, parent, column, city_name, status, image_filename):
        # Frame de la tarjeta
        card = ttk.Frame(parent, style='Card.TFrame')
        card.grid(row=0, column=column, padx=10, sticky='nsew')

        # Cargar y mostrar imagen
        image_path = os.path.join("imagenes", image_filename)
        photo = self.load_and_process_image(image_path)

        if photo:
            image_label = ttk.Label(card, image=photo, style='Modern.TLabel')
            image_label.image = photo
            image_label.pack(pady=(10, 5))

        # Nombre de la ciudad
        city_label = ttk.Label(
            card,
            text=city_name,
            font=('Helvetica', 14, 'bold'),
            style='Modern.TLabel'
        )
        city_label.pack(pady=(5, 0))

        # Estado/Jugadores
        status_label = ttk.Label(
            card,
            text=status,
            font=('Helvetica', 10),
            foreground='#60A5FA',  # Azul claro moderno
            style='Modern.TLabel'
        )
        status_label.pack(pady=(2, 10))

    def load_and_process_image(self, image_path, width=280, height=160):
        try:
            # Cargar y redimensionar imagen
            image = Image.open(image_path)
            image = image.resize((width, height), Image.Resampling.LANCZOS)

            # Añadir efecto de oscurecimiento sutil
            enhancer = ImageEnhance.Brightness(image)
            image = enhancer.enhance(0.7)

            return ImageTk.PhotoImage(image)
        except Exception as e:
            print(f"Error al cargar la imagen {image_path}: {e}")
            return None

    def create_action_button(self):
        # Frame contenedor para el botón
        button_frame = ttk.Frame(self.main_container, style='Modern.TFrame')
        button_frame.pack(pady=30)

        # Botón principal con hover effect
        play_button = tk.Button(
            button_frame,
            text="JUGAR AHORA",
            font=('Helvetica', 12, 'bold'),
            bg='#2563EB',  # Azul moderno
            fg='white',
            activebackground='#1D4ED8',  # Azul más oscuro para hover
            activeforeground='white',
            relief='flat',
            padx=40,
            pady=15,
            cursor='hand2'
        )
        play_button.pack()

    def create_footer(self):
        footer_frame = ttk.Frame(self.main_container, style='Modern.TFrame')
        footer_frame.pack(fill='x', pady=(20, 0))

        options = ["Opciones", "•", "Instrucciones", "•", "Ajustes", "•", "Iniciar sesión"]

        for option in options:
            label = ttk.Label(
                footer_frame,
                text=option,
                style='Footer.TLabel',
                cursor='hand2' if option != '•' else ''
            )
            label.pack(side='left', padx=5)


def main():
    root = tk.Tk()
    root.geometry("700x800")

    # Hacer que la ventana sea responsiva
    root.grid_rowconfigure(0, weight=1)
    root.grid_columnconfigure(0, weight=1)

    app = ModernTriviaUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
